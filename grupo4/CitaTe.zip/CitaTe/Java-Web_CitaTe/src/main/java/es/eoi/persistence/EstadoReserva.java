package es.eoi.persistence;

public enum EstadoReserva {
    ACEPTADA, PENDIENTE, RECHAZADA;
}
