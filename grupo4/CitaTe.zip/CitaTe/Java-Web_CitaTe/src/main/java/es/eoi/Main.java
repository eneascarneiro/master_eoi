package es.eoi;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");



    String historial = " ";
 <%
    if(historial != null){
        System.out.println("");
    }else{

        for (String dato : historial) {
            out.println("<li>" + dato + "</li>");
        }
    }
     %>


}

}