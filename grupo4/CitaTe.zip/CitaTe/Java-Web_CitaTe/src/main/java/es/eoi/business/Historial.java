package es.eoi.business;

import java.io.Serializable;

public class Historial implements Serializable {


}
