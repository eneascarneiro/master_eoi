package com.eoi.CitaTe.services;
import com.eoi.CitaTe.abstraccomponents.GenericServiceConJPA;
import com.eoi.CitaTe.entities.Empresa;
import org.springframework.stereotype.Service;

@Service
public class EmpresaService extends GenericServiceConJPA<Empresa, Long> {
}
