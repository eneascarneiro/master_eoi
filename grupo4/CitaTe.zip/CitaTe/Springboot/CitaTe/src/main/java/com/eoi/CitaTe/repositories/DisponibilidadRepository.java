package com.eoi.CitaTe.repositories;

import com.eoi.CitaTe.entities.Disponibilidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DisponibilidadRepository extends JpaRepository<Disponibilidad, Long> {
}