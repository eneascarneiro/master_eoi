package com.eoi.CitaTe.repositories;

import com.eoi.CitaTe.entities.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicioRepository extends JpaRepository<Servicio, Long> {
}