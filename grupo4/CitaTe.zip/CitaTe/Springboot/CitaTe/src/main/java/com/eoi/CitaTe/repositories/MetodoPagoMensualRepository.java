package com.eoi.CitaTe.repositories;

import com.eoi.CitaTe.entities.MetodoPagoMensual;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetodoPagoMensualRepository extends JpaRepository<MetodoPagoMensual, Long> {
}