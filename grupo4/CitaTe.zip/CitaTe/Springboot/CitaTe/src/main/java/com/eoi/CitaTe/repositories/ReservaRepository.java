package com.eoi.CitaTe.repositories;

import com.eoi.CitaTe.entities.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
}