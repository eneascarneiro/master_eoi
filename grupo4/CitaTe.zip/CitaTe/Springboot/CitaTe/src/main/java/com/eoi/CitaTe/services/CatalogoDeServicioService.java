package com.eoi.CitaTe.services;

import com.eoi.CitaTe.abstraccomponents.GenericServiceConJPA;
import com.eoi.CitaTe.entities.CatalogoDeServicio;
import org.springframework.stereotype.Service;

@Service
public class CatalogoDeServicioService extends GenericServiceConJPA<CatalogoDeServicio, Long> {
}
