package com.eoi.CitaTe.repositories;

import com.eoi.CitaTe.entities.CatalogoDeServicio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CatalogoDeServicioRepository extends JpaRepository<CatalogoDeServicio, Long> {
}