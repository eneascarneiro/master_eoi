package com.eoi.CitaTe.services;

import com.eoi.CitaTe.abstraccomponents.GenericServiceConJPA;
import com.eoi.CitaTe.entities.Disponibilidad;
import org.springframework.stereotype.Service;

@Service
public class DisponibilidadService extends GenericServiceConJPA<Disponibilidad, Long> {
}