insert into USUARIO (email,pass,activo,empleado,cliente) values (1,'empleado@gmail.com','puto',1,1,null);
insert into USUARIO (email,pass,activo,empleado,cliente) values (2,'cliente@gmail.com','puto',1,null,1);


--insert into CLIENTE (nombreCliente, apellido1Cliente,apellido2Cliente) values ('Alex','Muleta','Muleta');
--insert into MENU (url, descripcion,activo) values ('Menu_chulo','muy muy bien',1);





