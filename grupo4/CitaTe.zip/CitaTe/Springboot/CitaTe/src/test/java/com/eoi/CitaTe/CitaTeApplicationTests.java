package com.eoi.CitaTe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitaTeApplicationTests {

	@Test
	void contextLoads() {
	}

}
