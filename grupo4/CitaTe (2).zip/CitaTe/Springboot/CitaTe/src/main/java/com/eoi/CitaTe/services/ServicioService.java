package com.eoi.CitaTe.services;

import com.eoi.CitaTe.abstraccomponents.GenericServiceConJPA;
import com.eoi.CitaTe.entities.Servicio;
import org.springframework.stereotype.Service;

@Service
public class ServicioService extends GenericServiceConJPA<Servicio, Long> {
}
