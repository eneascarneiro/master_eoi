package com.eoi.CitaTe.services;


import com.eoi.CitaTe.abstraccomponents.GenericServiceConJPA;
import com.eoi.CitaTe.entities.Pago;
import org.springframework.stereotype.Service;

@Service
public class PagoService extends GenericServiceConJPA<Pago, Long> {
}
