package com.eoi.CitaTe.repositories;

import com.eoi.CitaTe.entities.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Long> {
}