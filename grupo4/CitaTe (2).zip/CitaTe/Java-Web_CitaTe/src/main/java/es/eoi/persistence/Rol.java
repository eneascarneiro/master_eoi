package es.eoi.persistence;

public enum Rol {

    USUARIO, EMPRESA, ADMIN;

}
